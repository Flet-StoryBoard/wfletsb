from fletsb.pages.main_page import mainPage

mainPage("myUI.fletsb")

# <script>
#     const head = document.getElementsByTagName('head')[0];
#     const base = document.createElement('base');
#     base.href = window.location.origin + window.location.pathname;
#     head.appendChild(base);
#   </script>