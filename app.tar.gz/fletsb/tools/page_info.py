
def get_page_bgcolor (content_dict, page_name):
    return content_dict["pages"][page_name]["settings"]["bgcolor"]
